<div class="modal fade" id="pilihSorting" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Pilih Metode Pengurutan ID</h5>
            </div>
            <div class="modal-body">
                <button class="btn btn-success col-12" type="button" id="sorting" data-dismiss="modal">
                    Dari Nilai Terbesar Hingga Terkecil
                </button>
                <button class="btn btn-success col-12" type="button" id="sorting2" data-dismiss="modal">Dari Nilai
                    Terkecil Hingga
                    Terbesar</button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>
</div>
{{-- End Modal Member --}}
